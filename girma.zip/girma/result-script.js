const query1 = sessionStorage.getItem('searchQuery');
const fullName = document.getElementById('name');
const phoneNo = document.getElementById('phone');
const boxContain = document.getElementById('box');

document.addEventListener('DOMContentLoaded', function () {

   
    
    const searchBox = document.getElementById('search');
    const resultsContainer = document.getElementById('container');
    
    // Fetch the JSON data
    async function fetchData() {
        try {
            const response = await fetch('user_list.json');
            return await response.json();
        } catch (error) {
            console.error('Error fetching the JSON file:', error);
            return [];
        }finally{
            
        }
    }

    // Function to filter and display results
    async function searchNames(query) {
        const data = await fetchData();
        const results = data.filter(person =>
            person.first_name.toLowerCase().includes(query.toLowerCase()) ||
            person.last_name.toLowerCase().includes(query.toLowerCase())
        );

        // Clear previous results
        resultsContainer.innerHTML = '';

        // Display results
        results.forEach(person => {
            const itemDiv = document.createElement('div');
            itemDiv.classList.add('box-container');
            itemDiv.textContent=`${person.first_name} ${person.last_name}`
            resultsContainer.appendChild(itemDiv);
        });

        // If no results
        if (results.length === 0) {
            const noResults = document.createElement('div');
            noResults.classList.add('box-container');
            noResults.textContent = 'No results found.';
            resultsContainer.appendChild(noResults);
        }
    }

    // Event listener for Enter key
    searchBox.addEventListener('keydown', function (event) {
        if (event.key === 'Enter') {
            event.preventDefault(); // Prevent form submission if inside a form
            searchNames(searchBox.value);
        }
    });
    if(query1){
        searchNames(query1);
    }
});