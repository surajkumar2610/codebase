document.addEventListener('DOMContentLoaded',()=>{
    const inputfield = document.getElementById('search');
    inputfield.addEventListener('keydown',(event)=>{
        if(event.key=='Enter'){
            const query1 = inputfield.value;
            if (query1) {
                sessionStorage.setItem('searchQuery', query1);
                window.location.href = 'result.html';
            }
        }
    })
})